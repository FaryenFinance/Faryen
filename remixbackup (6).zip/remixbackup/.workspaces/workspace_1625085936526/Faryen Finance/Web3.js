    var Web3 = require('web3');
    var web3 = new Web3(new Web3.providers.HttpProvider());
    var version = web3.version.api;
            
    $.getJSON('https://api.bscscan.com/api?module=contract&action=getabi&address=0x3E04083a9660167239A7b47f34e8867682Ce57Ce&apikey=YourApiKeyToken', function (data) {
    var contractABI = "";
        contractABI = JSON.parse(data.result);
        if (contractABI != ''){
            var MyContract = web3.eth.contract(contractABI);
            var myContractInstance = MyContract.at("0x3E04083a9660167239A7b47f34e8867682Ce57Ce");
            var result = myContractInstance.memberId("0xbc856E9BEB9DB1Ce56bb84D740a1B69aD9364D9E");
            console.log("result1 : " + result);
            var result = myContractInstance.members(1);
            console.log("result2 : " + result);
        } else {
            console.log("Error" );
        }
    });
                              